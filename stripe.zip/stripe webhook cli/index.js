const express=require('express')

const stripe=require('stripe')('sk_test_51LEAgTKNKs1XTnfCWAyhp9DpPTaIucEQke0lXjvldUq90LCVFwOdMDf9PfNLDFspVNM9KWTf5VQfQidozaOZZOxN00TorWX3ZU');

const bodyParser = require('body-parser');
const app=express();


app.post('/hooks',bodyParser.raw({type:"application/json"}),async(req,res)=>{
    let signinsecret="whsec_3c92064f99f75e8229621674005fcdade7860fe997fc9a7727bc2b6dc3b1ecbf"

    const payload=req.body
    const sig=req.headers['stripe-signature']

    //matching if the webhook is coming from stripe
    let event
    
    try{
        event=stripe.webhooks.constructEvent(payload,sig,signinsecret)
    }
    catch(error){
        console.log(error.message)
        res.status(400).json({sucess:false})
        return
    }

    //successful
    console.log(event.type)
    console.log(event.data.object)
    console.log(event.data.object.id)
    res.json({
        sucess:true
    })
})


app.listen(5000,()=>{
    console.log("App is listening on port 5000");
})

