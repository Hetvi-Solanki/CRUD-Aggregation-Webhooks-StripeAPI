const express = require('express');
const bodyParser=require('body-parser');
const path = require('path');
const { createDecipheriv } = require('crypto');

const PUBLISHABLE_KEY="pk_test_51LaibWSAB5XHoy64xQiO3ycB2D1hmVFbS6OR6UHGtdJKJ4muHcUqSQBDV5NwzRjArpzef9DEcYiXJtMBgSlGCedJ00TYzkmUdB";
const SECRET_KEY="sk_test_51LaibWSAB5XHoy64TdH5syrhxCzHnUAZ78nlqzasVFGBSuvKi46numjDGaqdBkTUwOtf3wUz6dEzEsjjbC2JElLS00JA78LWvJ";

const stripe=require('stripe')(SECRET_KEY);

const app = express();

app.use(bodyParser.urlencoded({extended:false}))
app.use(bodyParser.json())

app.set("view engine","ejs");

const PORT = process.env.PORT || 3000;

app.get('/',(req,res) => {
    res.render('Home',{
        key:PUBLISHABLE_KEY
    })
})

app.post('/payment',(req,res)=>{
    stripe.customers.create({
        email:req.body.stripeEmail,
        source:req.body.stripeToken,
        name:'Het Mehta',
        address:{
            line1:'201 Anupam Appt.',
            postal_code:'396001',
            city:'Valsad',
            state:'Gujarat',
            country:'India'
        }
    })
    .then((customer)=>{
        return stripe.paymentIntents.create({
            amount:7000,
            description:'Our product',
            currency:'usd',
            customer:customer.id,

        })
    })
    .then((charge)=>{
        console.log(charge);
        res.send("Payment Sucess!!")
    })
    .catch((err) => {
        res.send(err)
    })
})

app.listen(PORT,()=>{
    console.log(`App is listening on ${PORT}`);
})