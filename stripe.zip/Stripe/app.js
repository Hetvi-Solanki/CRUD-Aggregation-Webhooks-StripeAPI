// const express = require('express')
// const app = express()

// app.get('/', function (req, res) {
//   res.send('Hello World')
// })

// app.listen(3000)

var express=require('express');
const stripe = require('stripe')('sk_test_51LEAgTKNKs1XTnfCWAyhp9DpPTaIucEQke0lXjvldUq90LCVFwOdMDf9PfNLDFspVNM9KWTf5VQfQidozaOZZOxN00TorWX3ZU');

var app=express();

app.listen(3000,function(){
    console.log("Server Running");
})

var createCustomer = function(){
    var param = {};
    param.email = "hetabc@gmail.com";
    param.name = "hetabc";
    param.description = "from node c3";

    stripe.customers.create(param, function(err,customer){
        if(err){
            console.log("Error: "+err);
        }
        if(customer){
            console.log("Success: "+JSON.stringify(customer,null,2));
        }
        else{
            console.log("Something went wrong!!");
        }
    })
}

//createCustomer();


var retrieveCustomer = function(){
    stripe.customers.retrieve("cus_MJXT5LwC79rDwg", function(err,customer){
        if(err){
            console.log("Error: "+err);
        }
        if(customer){
            console.log("Success: "+JSON.stringify(customer,null,2));
        }
        else{
            console.log("Something went wrong!!");
        }
    })
}

//retrieveCustomer();

var createToken = function(){

    var param={};
    param.card = {
        number:'4242 4242 4242 4242',
        exp_month:6,
        exp_year:2024,
        cvc:'347'
    }

    stripe.tokens.create(param, function(err,token){
        if(err){
            console.log("Error: "+err);
        }
        if(token){
            console.log("Success: "+JSON.stringify(token,null,2));
        }
        else{
            console.log("Something went wrong!!");
        }
    })
}

//createToken();

var addCardToCustomer = function(){

    stripe.customers.createSource("cus_MJiXttZ5frgjdz",{source:"tok_1Lb5PCKNKs1XTnfCJQjFnpAj"}, function(err,card){
        if(err){
            console.log("Error: "+err);
        }
        if(card){
            console.log("Success: "+JSON.stringify(card,null,2));
        }
        else{
            console.log("Something went wrong!!");
        }
    })
}

//addCardToCustomer();

var chargeCustomerThroughCustomerID = function(){
    var param = {
        amount:'2000',
        currency:'usd',
        description:'First Payment',
        customer:'cus_MJiXttZ5frgjdz'
    };
    

    stripe.charges.create(param, function(err,charge){
        if(err){
            console.log("Err: "+err);
        }
        if(charge){
            console.log("Success: "+JSON.stringify(charge,null,2));
        }
        else{
            console.log("Something went wrong!!");
        }
    })
}

//chargeCustomerThroughCustomerID();

var chargeCustomerThroughTokenID = function(){
    var param = {
        amount:'2000',
        currency:'usd',
        description:'First Payment',
        source:'tok_1Lb5PCKNKs1XTnfCJQjFnpAj'
    };
    

    stripe.charges.create(param, function(err,charge){
        if(err){
            console.log("Err: "+err);
        }
        if(charge){
            console.log("Success: "+JSON.stringify(charge,null,2));
        }
        else{
            console.log("Something went wrong!!");
        }
    })
}

//chargeCustomerThroughTokenID();

var getAllCustomers = function(){
    
    stripe.customers.list({limit: 4},function(err,customers){
        if(err){
            console.log("Err: "+err);
        }
        if(customers){
            console.log("Success: "+JSON.stringify(customers.data,null,2));
        }
        else{
            console.log("Something went wrong!!");
        }
    })
}

//getAllCustomers();

//------------------Subscription------------------------------

//create subscription
const createSubscription = function(){
    var param = {
        customer: 'cus_MJiXttZ5frgjdz',
        items: [
                    {price: 'price_1LavrjKNKs1XTnfCFB76CGu0'}
               ]
    };
    

    stripe.subscriptions.create(param, function(err,subscription){
        if(err){
            console.log("Err: "+err);
        }
        if(subscription){
            console.log("Success: "+JSON.stringify(subscription,null,2));
        }
        else{
            console.log("Something went wrong!!");
        }
    })
}
//createSubscription();


//Retrieve Subscription
const retrieveSubscription = function(){
    stripe.subscriptions.retrieve("sub_1Lb4hgKNKs1XTnfCAp1u8fMG", function(err,subscription){
        if(err){
            console.log("Error: "+err);
        }
        if(subscription){
            console.log("Success: "+JSON.stringify(subscription,null,2));
        }
        else{
            console.log("Something went wrong!!");
        }
    })
}
//retrieveSubscription();

const updateSubscription = function(){
    
    
    stripe.subscriptions.update('sub_1Lb5VkKNKs1XTnfChC1eAVPF',{metadata: {order_id: '6735'}},function(err,subscription){
        if(err){
            console.log("Error: "+err);
        }
        if(subscription){
            console.log("Success: "+JSON.stringify(subscription,null,2));
        }
        else{
            console.log("Something went wrong!!");
        }
    })
}
//updateSubscription();

const deleteSubscription = function(){
    
    
    stripe.subscriptions.del('sub_1Lb5NAKNKs1XTnfCa7wel69z',function(err,subscription){
        if(err){
            console.log("Error: "+err);
        }
        if(subscription){
            console.log("Success: "+JSON.stringify(subscription,null,2));
        }
        else{
            console.log("Something went wrong!!");
        }
    })
}
//deleteSubscription();

var getAllSubscriptions = function(){
    
    stripe.subscriptions.list({limit: 2},function(err,subscriptions){
        if(err){
            console.log("Err: "+err);
        }
        if(subscriptions){
            console.log("Success: "+JSON.stringify(subscriptions.data,null,2));
        }
        else{
            console.log("Something went wrong!!");
        }
    })
}

//getAllSubscriptions();

var searchSubscription = function(){
    
    stripe.subscriptions.search({query: 'status:\'active\' AND metadata[\'order_id\']:\'6735\''},function(err,subscription){
        if(err){
            console.log("Err: "+err);
        }
        if(subscription){
            console.log("Success: "+JSON.stringify(subscription,null,2));
        }
        else{
            console.log("Something went wrong!!");
        }
    })
}

//searchSubscription();

const createSubscriptionItem = function(){
    var param = {
        subscription: 'sub_1Lb4hgKNKs1XTnfCAp1u8fMG',
        price: 'price_1LavrjKNKs1XTnfCFB76CGu0',
        quantity: 4
    };
    

    stripe.subscriptionItems.create(param, function(err,subscriptionItem){
        if(err){
            console.log("Err: "+err);
        }
        if(subscriptionItem){
            console.log("Success: "+JSON.stringify(subscriptionItem,null,2));
        }
        else{
            console.log("Something went wrong!!");
        }
    })
}
//createSubscriptionItem();

const createSchedule = function(){
    var param = {
        customer: 'cus_MJXT5LwC79rDwg',
        start_date: 1662135896,
        end_behavior: 'release',
        phases: [
            {
            items: [
                {
                price: 'price_1LavrjKNKs1XTnfCFB76CGu0',
                quantity: 1,
                },
            ],
            iterations: 12,
            },
        ]
    };
    

    stripe.subscriptionSchedules.create(param, function(err,subscriptionSchedule){
        if(err){
            console.log("Err: "+err);
        }
        if(subscriptionSchedule){
            console.log("Success: "+JSON.stringify(subscriptionSchedule,null,2));
        }
        else{
            console.log("Something went wrong!!");
        }
    })
}
//createSchedule();

const retrieveSchedule = function(){
    stripe.subscriptionSchedules.retrieve("sub_1Lb4hgKNKs1XTnfCAp1u8fMG", function(err,subscription){
        if(err){
            console.log("Error: "+err);
        }
        if(subscription){
            console.log("Success: "+JSON.stringify(subscription,null,2));
        }
        else{
            console.log("Something went wrong!!");
        }
    })
}
//retrieveSchedule();

const updateSchedule = function(){
    
    
    stripe.subscriptionSchedules.update('sub_1Lb4hgKNKs1XTnfCAp1u8fMG',{end_behavior: 'release'},function(err,subscription){
        if(err){
            console.log("Error: "+err);
        }
        if(subscription){
            console.log("Success: "+JSON.stringify(subscription,null,2));
        }
        else{
            console.log("Something went wrong!!");
        }
    })
}
//updateSchedule();

