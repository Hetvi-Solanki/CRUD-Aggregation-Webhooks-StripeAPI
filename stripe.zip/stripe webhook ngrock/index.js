const stripe = require('stripe')('sk_test_51LEAgTKNKs1XTnfCWAyhp9DpPTaIucEQke0lXjvldUq90LCVFwOdMDf9PfNLDFspVNM9KWTf5VQfQidozaOZZOxN00TorWX3ZU');

const express = require('express')

const dotenv = require('dotenv')
dotenv.config()

const nodemailer = require('nodemailer')

const app = express()

//deploy app publically-ngrok
app.get('/', (req, res) => {
    res.send("Hello World!");
})

let endpointSecret = "whsec_0EVHifi7SG0NfeZISdnvff6JSVyjW4hg"
let session = ""
let product="https://drive.google.com/file/d/1BqOX-7sCjQL-DXdyH3fd9T9CLxb-JWFL/view?usp=sharing"
//webhook

app.post('/webhooks', express.raw({ type: 'application/json' }),async (request, response) => {
    const sig = request.headers['stripe-signature'];
    //coming from stripe

    let event;

    try {
        event = stripe.webhooks.constructEvent(request.body, sig, endpointSecret);
    } catch (err) {
        response.status(400).send(`Webhook Error: ${err.message}`);
        return;
    }

    // Handle the event
    switch (event.type) {
        case 'checkout.session.async_payment_failed':
            session = event.data.object;
            // Then define and call a function to handle the event checkout.session.async_payment_failed
            break;
        case 'checkout.session.completed':
            session = event.data.object;

            let emailto = session.customer_details.email

            let transporter = nodemailer.createTransport({
                host: "smtp.gmail.com",
                port: 587,
                secure: false, // true for 465, false for other ports
                auth: {
                    user: process.env.email, // generated ethereal user
                    pass: process.env.password, // generated ethereal password
                },
            });

            // send mail with defined transport object
            let info = await transporter.sendMail({
                from: process.env.email, // sender address
                to: emailto, // list of receivers
                subject: "Thanks for the payment of the Product", // Subject line
                text: "Hello! Your Payment has been received for the product. Thanks!!", // plain text body
                html: `
                    Hello ${session.customer_details.email}. 
                    Thanks for the payment!
                    Here is the link for the product: ${product}.
                    Congratulations! You've got the unlimited excess for the product.
                    You can Download it via above link.
                    Thank You.
                `, // html body
            });

            console.log("Message sent: %s", info.messageId);
            // Then define and call a function to handle the event checkout.session.async_payment_succeeded
            break;
        // ... handle other event types
        default:
            console.log(`Unhandled event type ${event.type}`);
    }

    // Return a 200 response to acknowledge receipt of the event
    response.send();
});


app.listen(5000, () => {
    console.log("App is listening on port 5000");
})

