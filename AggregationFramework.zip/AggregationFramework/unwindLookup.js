//customers - authors
//For each Genre, get author name

db.customers.aggregate([
    {
        $unwind:"$preferred_book_type"
    },
    {
        $group:{
                    _id:"$preferred_book_type"
        }
    },
    {
        $lookup:{
                    from:"authors",
                    localField:"_id",
                    foreignField:"book_type",
                    as:"auth"
        }
    },
    {
        $project:{
                    _id:1,
                    "auth.auth_name":1
        }
    }
                    
])

// ---------------------------------------Output--------------------------------------------//

/* 1 */
{
    "_id" : "Action",
    "auth" : [ 
        {
            "auth_name" : "HDS"
        }
    ]
}

/* 2 */
{
    "_id" : "Fiction",
    "auth" : [ 
        {
            "auth_name" : "AKS"
        }, 
        {
            "auth_name" : "RJB"
        }
    ]
}

/* 3 */
{
    "_id" : "Horror",
    "auth" : [ 
        {
            "auth_name" : "RJT"
        }
    ]
}

/* 4 */
{
    "_id" : "Comedy",
    "auth" : [ 
        {
            "auth_name" : "KJS"
        }, 
        {
            "auth_name" : "UDS"
        }, 
        {
            "auth_name" : "DAS"
        }
    ]
}

/* 5 */
{
    "_id" : "Religious",
    "auth" : []
}