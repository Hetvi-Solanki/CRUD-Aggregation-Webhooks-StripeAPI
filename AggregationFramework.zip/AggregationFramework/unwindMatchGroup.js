//customers
//Got the name who loves fiction and action book

db.customers.aggregate([
    {
        $unwind:"$preferred_book_type"//split the array
    },
    {
        $match:{
                    //To get data of fiction and action
                    preferred_book_type: /ion/
               }
    },
    {
        $group:{
                    _id:"$name", //groups according to username
                    FavGenre: {
                                $push:"$preferred_book_type" //creates an array
                               }
               }
    }
])
    
// ---------------------------------------Output--------------------------------------------//

/* 1 */
{
    "_id" : "Siya",
    "FavGenre" : [ 
        "Action", 
        "Fiction"
    ]
}

/* 2 */
{
    "_id" : "Radha",
    "FavGenre" : [ 
        "Fiction", 
        "Fiction", 
        "Action", 
        "Fiction"
    ]
}

/* 3 */
{
    "_id" : "Sneha",
    "FavGenre" : [ 
        "Fiction"
    ]
}

/* 4 */
{
    "_id" : "shrey",
    "FavGenre" : [ 
        "Fiction"
    ]
}

/* 5 */
{
    "_id" : "Priya",
    "FavGenre" : [ 
        "Action"
    ]
}

/* 6 */
{
    "_id" : "Meet",
    "FavGenre" : [ 
        "Fiction", 
        "Fiction"
    ]
}

/* 7 */
{
    "_id" : "Raj",
    "FavGenre" : [ 
        "Action"
    ]
}

/* 8 */
{
    "_id" : "Sita",
    "FavGenre" : [ 
        "Fiction", 
        "Action", 
        "Action", 
        "Fiction"
    ]
}