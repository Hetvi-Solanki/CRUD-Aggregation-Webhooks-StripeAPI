//authors
//Get the youndest and oldest age of author for particular genre
//Find the no of sales for one Genre and sort them


//$limit- no of docs
//$skip:3 ==> skip first three docs
//used in paging
// $skip : 10 * (page_no), $limit:10 --> On each page 10 records


//db.customers.distinct("city")


//Find
//db.customers.find({age:{$gt:20}})

//db.orders.find({book_name:"oop"})
//Output:
/* 1 */
// {
//     "_id" : ObjectId("62f5393e6bcd05ea73c85273"),
//     "book_name" : "oop",
//     "customer_name" : "Utsav",
//     "total_copies" : 1,
//     "__v" : 0
// }

// /* 2 */
// {
//     "_id" : ObjectId("62f5394b6bcd05ea73c85275"),
//     "book_name" : "oop",
//     "customer_name" : "Raj",
//     "total_copies" : 5,
//     "__v" : 0
// }


//--------------------------------------------------------------------------------------------------//


db.authors.aggregate([
    {
        $sort: {age: -1}
    }, 
    {
        $group: {
                  _id: "$book_type",
                  oldestAge:{$first:"$age"},
                  youngestAge:{$last:"$age"},
                  total_sale:{$sum:"$no_of_copies_sold"}
              }
    },
    {   
        $sort: {total_sale:-1}
    }
])

// ---------------------------------------Output--------------------------------------------//

/* 1 */
{
    "_id" : "Comedy",
    "oldestAge" : 60,
    "youngestAge" : 60,
    "total_sale" : 1710
}

/* 2 */
{
    "_id" : "Action",
    "oldestAge" : 68,
    "youngestAge" : 68,
    "total_sale" : 500
}

/* 3 */
{
    "_id" : "Fiction",
    "oldestAge" : 50,
    "youngestAge" : 45,
    "total_sale" : 89
}

/* 4 */
{
    "_id" : "Horror",
    "oldestAge" : 69,
    "youngestAge" : 69,
    "total_sale" : 50
}