//Total orders of a customer till now
db.orders.aggregate([
    {
        $group:{
                    _id:"$customer_name",
                    total_orders:{ $sum: "$total_copies"}
                }
            }
    ])

//----------------------------OUTput-------------------

/* 1 */
{
    "_id" : "Meet",
    "total_orders" : 20
}

/* 2 */
{
    "_id" : "Hetvi",
    "total_orders" : 16
}

/* 3 */
{
    "_id" : "Utsav",
    "total_orders" : 17
}

/* 4 */
{
    "_id" : "Raj",
    "total_orders" : 11
}