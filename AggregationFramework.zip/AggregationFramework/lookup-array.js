//customers-genres
//get book_details of genre present in array

db.customers.aggregate([
    {
        $lookup:{
                    from:"genres",
                    localField:"preferred_book_type",
                    foreignField:"genre",
                    as:"type"
        }
    },
    {
        $project:{
                    name:1,
                    preferred_book_type:1,
                    "type.title":1,
                    "type.genre":1,
                    "type.author":1
        }
    }
])

// ---------------------------------------Output--------------------------------------------//

/* 1 */
{
    "_id" : ObjectId("62f53ff65ff140f0004cbabe"),
    "name" : "Sita",
    "preferred_book_type" : [ 
        "Fiction", 
        "Action"
    ],
    "type" : [ 
        {
            "title" : "DSA",
            "genre" : "Fiction",
            "author" : "HDS"
        }, 
        {
            "title" : "Power of your subconcious mind",
            "genre" : "Fiction",
            "author" : "UDS"
        }, 
        {
            "title" : "OOP",
            "genre" : "Fiction",
            "author" : "UDS"
        }, 
        {
            "title" : "OOP",
            "genre" : "Action",
            "author" : "KJS"
        }, 
        {
            "title" : "Power of your subconcious mind",
            "genre" : "Fiction",
            "author" : "DAS"
        }, 
        {
            "title" : "OOP",
            "genre" : "Fiction",
            "author" : "AKS"
        }
    ]
}

/* 2 */
{
    "_id" : ObjectId("62f540215ff140f0004cbac0"),
    "name" : "Siya",
    "preferred_book_type" : "Action",
    "type" : [ 
        {
            "title" : "OOP",
            "genre" : "Action",
            "author" : "KJS"
        }
    ]
}

/* 3 */
{
    "_id" : ObjectId("62f540335ff140f0004cbac2"),
    "name" : "Siya",
    "preferred_book_type" : [ 
        "Horror", 
        "Fiction"
    ],
    "type" : [ 
        {
            "title" : "DSA",
            "genre" : "Fiction",
            "author" : "HDS"
        }, 
        {
            "title" : "Power of your subconcious mind",
            "genre" : "Fiction",
            "author" : "UDS"
        }, 
        {
            "title" : "OOP",
            "genre" : "Fiction",
            "author" : "UDS"
        }, 
        {
            "title" : "DSA",
            "genre" : "Horror",
            "author" : "UDS"
        }, 
        {
            "title" : "DSA",
            "genre" : "Horror",
            "author" : "KJS"
        }, 
        {
            "title" : "Power of your subconcious mind",
            "genre" : "Fiction",
            "author" : "DAS"
        }, 
        {
            "title" : "OOP",
            "genre" : "Fiction",
            "author" : "AKS"
        }, 
        {
            "title" : "DSA",
            "genre" : "Horror",
            "author" : "AKS"
        }, 
        {
            "title" : "DSA",
            "genre" : "Horror",
            "author" : "RGB"
        }
    ]
}

/* 4 */
{
    "_id" : ObjectId("62f5403e5ff140f0004cbac4"),
    "name" : "Sita",
    "preferred_book_type" : [ 
        "Horror", 
        "Action", 
        "Fiction"
    ],
    "type" : [ 
        {
            "title" : "DSA",
            "genre" : "Fiction",
            "author" : "HDS"
        }, 
        {
            "title" : "Power of your subconcious mind",
            "genre" : "Fiction",
            "author" : "UDS"
        }, 
        {
            "title" : "OOP",
            "genre" : "Fiction",
            "author" : "UDS"
        }, 
        {
            "title" : "DSA",
            "genre" : "Horror",
            "author" : "UDS"
        }, 
        {
            "title" : "DSA",
            "genre" : "Horror",
            "author" : "KJS"
        }, 
        {
            "title" : "OOP",
            "genre" : "Action",
            "author" : "KJS"
        }, 
        {
            "title" : "Power of your subconcious mind",
            "genre" : "Fiction",
            "author" : "DAS"
        }, 
        {
            "title" : "OOP",
            "genre" : "Fiction",
            "author" : "AKS"
        }, 
        {
            "title" : "DSA",
            "genre" : "Horror",
            "author" : "AKS"
        }, 
        {
            "title" : "DSA",
            "genre" : "Horror",
            "author" : "RGB"
        }
    ]
}

/* 5 */
{
    "_id" : ObjectId("62f542d55ff140f0004cbad8"),
    "name" : "Sneha",
    "preferred_book_type" : "Fiction",
    "type" : [ 
        {
            "title" : "DSA",
            "genre" : "Fiction",
            "author" : "HDS"
        }, 
        {
            "title" : "Power of your subconcious mind",
            "genre" : "Fiction",
            "author" : "UDS"
        }, 
        {
            "title" : "OOP",
            "genre" : "Fiction",
            "author" : "UDS"
        }, 
        {
            "title" : "Power of your subconcious mind",
            "genre" : "Fiction",
            "author" : "DAS"
        }, 
        {
            "title" : "OOP",
            "genre" : "Fiction",
            "author" : "AKS"
        }
    ]
}

/* 6 */
{
    "_id" : ObjectId("62f542e95ff140f0004cbada"),
    "name" : "Priya",
    "preferred_book_type" : [ 
        "Comedy", 
        "Action"
    ],
    "type" : [ 
        {
            "title" : "OOP",
            "genre" : "Comedy",
            "author" : "HDS"
        }, 
        {
            "title" : "OOP",
            "genre" : "Action",
            "author" : "KJS"
        }
    ]
}

/* 7 */
{
    "_id" : ObjectId("62f542fd5ff140f0004cbadc"),
    "name" : "Radha",
    "preferred_book_type" : [ 
        "Comedy", 
        "Fiction", 
        "Horror"
    ],
    "type" : [ 
        {
            "title" : "OOP",
            "genre" : "Comedy",
            "author" : "HDS"
        }, 
        {
            "title" : "DSA",
            "genre" : "Fiction",
            "author" : "HDS"
        }, 
        {
            "title" : "Power of your subconcious mind",
            "genre" : "Fiction",
            "author" : "UDS"
        }, 
        {
            "title" : "OOP",
            "genre" : "Fiction",
            "author" : "UDS"
        }, 
        {
            "title" : "DSA",
            "genre" : "Horror",
            "author" : "UDS"
        }, 
        {
            "title" : "DSA",
            "genre" : "Horror",
            "author" : "KJS"
        }, 
        {
            "title" : "Power of your subconcious mind",
            "genre" : "Fiction",
            "author" : "DAS"
        }, 
        {
            "title" : "OOP",
            "genre" : "Fiction",
            "author" : "AKS"
        }, 
        {
            "title" : "DSA",
            "genre" : "Horror",
            "author" : "AKS"
        }, 
        {
            "title" : "DSA",
            "genre" : "Horror",
            "author" : "RGB"
        }
    ]
}

/* 8 */
{
    "_id" : ObjectId("62f5430b5ff140f0004cbade"),
    "name" : "Radha",
    "preferred_book_type" : [ 
        "Religious", 
        "Fiction", 
        "Action"
    ],
    "type" : [ 
        {
            "title" : "DSA",
            "genre" : "Fiction",
            "author" : "HDS"
        }, 
        {
            "title" : "Power of your subconcious mind",
            "genre" : "Fiction",
            "author" : "UDS"
        }, 
        {
            "title" : "OOP",
            "genre" : "Fiction",
            "author" : "UDS"
        }, 
        {
            "title" : "OOP",
            "genre" : "Action",
            "author" : "KJS"
        }, 
        {
            "title" : "Power of your subconcious mind",
            "genre" : "Fiction",
            "author" : "DAS"
        }, 
        {
            "title" : "OOP",
            "genre" : "Fiction",
            "author" : "AKS"
        }
    ]
}

/* 9 */
{
    "_id" : ObjectId("62f5431e5ff140f0004cbae0"),
    "name" : "Radha",
    "preferred_book_type" : "Fiction",
    "type" : [ 
        {
            "title" : "DSA",
            "genre" : "Fiction",
            "author" : "HDS"
        }, 
        {
            "title" : "Power of your subconcious mind",
            "genre" : "Fiction",
            "author" : "UDS"
        }, 
        {
            "title" : "OOP",
            "genre" : "Fiction",
            "author" : "UDS"
        }, 
        {
            "title" : "Power of your subconcious mind",
            "genre" : "Fiction",
            "author" : "DAS"
        }, 
        {
            "title" : "OOP",
            "genre" : "Fiction",
            "author" : "AKS"
        }
    ]
}

/* 10 */
{
    "_id" : ObjectId("62f543285ff140f0004cbae2"),
    "name" : "shrey",
    "preferred_book_type" : [ 
        "Fiction", 
        "Comedy"
    ],
    "type" : [ 
        {
            "title" : "OOP",
            "genre" : "Comedy",
            "author" : "HDS"
        }, 
        {
            "title" : "DSA",
            "genre" : "Fiction",
            "author" : "HDS"
        }, 
        {
            "title" : "Power of your subconcious mind",
            "genre" : "Fiction",
            "author" : "UDS"
        }, 
        {
            "title" : "OOP",
            "genre" : "Fiction",
            "author" : "UDS"
        }, 
        {
            "title" : "Power of your subconcious mind",
            "genre" : "Fiction",
            "author" : "DAS"
        }, 
        {
            "title" : "OOP",
            "genre" : "Fiction",
            "author" : "AKS"
        }
    ]
}

/* 11 */
{
    "_id" : ObjectId("62f543345ff140f0004cbae4"),
    "name" : "Meet",
    "preferred_book_type" : "Fiction",
    "type" : [ 
        {
            "title" : "DSA",
            "genre" : "Fiction",
            "author" : "HDS"
        }, 
        {
            "title" : "Power of your subconcious mind",
            "genre" : "Fiction",
            "author" : "UDS"
        }, 
        {
            "title" : "OOP",
            "genre" : "Fiction",
            "author" : "UDS"
        }, 
        {
            "title" : "Power of your subconcious mind",
            "genre" : "Fiction",
            "author" : "DAS"
        }, 
        {
            "title" : "OOP",
            "genre" : "Fiction",
            "author" : "AKS"
        }
    ]
}

/* 12 */
{
    "_id" : ObjectId("62f543445ff140f0004cbae6"),
    "name" : "Meet",
    "preferred_book_type" : "Fiction",
    "type" : [ 
        {
            "title" : "DSA",
            "genre" : "Fiction",
            "author" : "HDS"
        }, 
        {
            "title" : "Power of your subconcious mind",
            "genre" : "Fiction",
            "author" : "UDS"
        }, 
        {
            "title" : "OOP",
            "genre" : "Fiction",
            "author" : "UDS"
        }, 
        {
            "title" : "Power of your subconcious mind",
            "genre" : "Fiction",
            "author" : "DAS"
        }, 
        {
            "title" : "OOP",
            "genre" : "Fiction",
            "author" : "AKS"
        }
    ]
}

/* 13 */
{
    "_id" : ObjectId("62f5435a5ff140f0004cbae8"),
    "name" : "Raj",
    "preferred_book_type" : "Horror",
    "type" : [ 
        {
            "title" : "DSA",
            "genre" : "Horror",
            "author" : "UDS"
        }, 
        {
            "title" : "DSA",
            "genre" : "Horror",
            "author" : "KJS"
        }, 
        {
            "title" : "DSA",
            "genre" : "Horror",
            "author" : "AKS"
        }, 
        {
            "title" : "DSA",
            "genre" : "Horror",
            "author" : "RGB"
        }
    ]
}

/* 14 */
{
    "_id" : ObjectId("62f5436e5ff140f0004cbaec"),
    "name" : "Raj",
    "preferred_book_type" : "Action",
    "type" : [ 
        {
            "title" : "OOP",
            "genre" : "Action",
            "author" : "KJS"
        }
    ]
}