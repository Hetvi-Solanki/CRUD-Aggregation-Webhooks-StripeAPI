// authors - books (collection)
//Run in Robo3T
//Get book_details by author_name
db.authors.aggregate([ 
    {
        $lookup:{
                    from:"books",
                    localField:"auth_name",
                    foreignField:"author",
                    as:"book_details"
                }
    },
    {
        $project:{
                    auth_name:1,
                    "book_details.title":1,
                    "book_details.price":1
                 } 
    }
])

// ---------------------------------------Output--------------------------------------------//

/* 1 */
{
    "_id" : ObjectId("62f53b845ff140f0004cba99"),
    "auth_name" : "HDS",
    "book_details" : [ 
        {
            "title" : "The Power of your Subconsious Mind",
            "price" : 190
        }, 
        {
            "title" : "OOP",
            "price" : 570
        }, 
        {
            "title" : "dsa",
            "price" : 840
        }, 
        {
            "title" : "oop",
            "price" : 525
        }
    ]
}

/* 2 */
{
    "_id" : ObjectId("62f53baa5ff140f0004cba9b"),
    "auth_name" : "RJT",
    "book_details" : []
}

/* 3 */
{
    "_id" : ObjectId("62f53c275ff140f0004cba9f"),
    "auth_name" : "KJS",
    "book_details" : [ 
        {
            "title" : "dsa",
            "price" : 400
        }, 
        {
            "title" : "oop",
            "price" : 525
        }
    ]
}

/* 4 */
{
    "_id" : ObjectId("62f53c465ff140f0004cbaa2"),
    "auth_name" : "UDS",
    "book_details" : [ 
        {
            "title" : "dsa",
            "price" : 440
        }, 
        {
            "title" : "oop",
            "price" : 440
        }, 
        {
            "title" : "oop",
            "price" : 544
        }
    ]
}

/* 5 */
{
    "_id" : ObjectId("62f5442d5ff140f0004cbb00"),
    "auth_name" : "DAS",
    "book_details" : [ 
        {
            "title" : "dsa",
            "price" : 50
        }, 
        {
            "title" : "dsa",
            "price" : 510
        }
    ]
}

/* 6 */
{
    "_id" : ObjectId("62f544415ff140f0004cbb02"),
    "auth_name" : "AKS",
    "book_details" : [ 
        {
            "title" : "oop",
            "price" : 525
        }
    ]
}

/* 7 */
{
    "_id" : ObjectId("62f5445a5ff140f0004cbb04"),
    "auth_name" : "RJB",
    "book_details" : []
}