import React,{useState} from 'react';

function TableBook(props){
    const {books,onDelete,onUpdate} = props;

    return(
        <table>
            <thead>
            <tr>
                <td>Title</td>
                <td>Description</td>
            </tr>
            </thead>
            <tbody>
            {
                books.map(book=>{
                    return(
                        <tr key={book._id}>
                            <td>{book.title}</td>
                            <td><DescriptionForm book={book} onUpdate={onUpdate} /></td>
                            <td><button onClick={ ()=> onDelete(book._id)}>Delete</button></td>
                        </tr>
                    )
                })
            }
            </tbody>
        </table>
    )
}


function DescriptionForm(props){

    const {book,onUpdate} = props;

    const [description,setDescription] = useState(book.description);

    const handleChange = (e) => {
        setDescription(e.target.value);
      };
    
      

    return(
        <table>
            <tbody>
            <tr>
                <td>
                    <input type="text"  value={description} onChange={handleChange} />
                </td>
                
                <td>
                    <button onClick={()=>onUpdate({_id:book._id, description:description})}>Update</button>
                </td>
            </tr>
            </tbody>
        </table>
    )
}

export default TableBook;