const express = require('express');
const app=express();
const cors=require('cors');
const bodyParser=require('body-parser');
const authorsRoute=require('./routes/authors');
const booksRoute=require('./routes/books');
const customersRoute=require('./routes/customers');
const genresRoute=require('./routes/genres');
const ordersRoute=require('./routes/orders');
const mongoose = require('mongoose');

app.use(cors());

mongoose.connect("mongodb+srv://HetviSolanki:hetvi2002@cluster0.lyopu.mongodb.net/?retryWrites=true&w=majority")
.then(()=>console.log('connected'))
.catch(e=>console.log(e));


app.use(bodyParser.json());
app.use('/authors',authorsRoute);
app.use('/books',booksRoute);
app.use('/customers',customersRoute);
app.use('/genres',genresRoute);
app.use('/orders',ordersRoute);

app.listen(4000);