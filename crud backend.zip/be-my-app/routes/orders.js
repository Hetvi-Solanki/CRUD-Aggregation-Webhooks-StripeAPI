const express = require('express');
const Order = require('../models/Order');
const router = express.Router();


router.get('/',(req,res)=>{

    
    Order.find()
        .then(data =>{
           res.json(data);
        })
        .catch(e=>{
            console.log(e.stack);
            
        })
        
        .catch(e=>{
            res.json({message:e})
        })

});

router.post('/',(req,res)=>{
    const order=new Order({
        book_name: req.body.book_name,
        customer_name: req.body.customer_name,
        total_copies: req.body.total_copies
        
    });

    order.save()
        .then(data =>{
           res.json(data);
        })
        .catch(e=>{
            console.log(e.stack);
           
        })

        
});

router.delete('/:id',(req,res)=>{
    Order.deleteOne({_id:req.params.id})
        .then(data => {
           return res.json(data);
        })
        .catch(e=>{
            res.json({message:e});
        })
});

router.patch('/:id',(req,res)=>{
    Order.updateOne({_id:req.params.id},{
        $set:req.body
    })
    .then(data =>{
       res.json(data);
    })
    .catch(e =>{
        console.log(e.stack);
    })
});

module.exports=router;