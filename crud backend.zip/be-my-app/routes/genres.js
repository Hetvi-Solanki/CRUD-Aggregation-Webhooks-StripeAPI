const express = require('express');
const Genre = require('../models/Genre');
const router = express.Router();


router.get('/',(req,res)=>{

    
    Genre.find()
        .then(data =>{
           res.json(data);
        })
        .catch(e=>{
            console.log(e.stack);
            
        })
        
        .catch(e=>{
            res.json({message:e})
        })

});

router.post('/',(req,res)=>{
    const genre=new Genre({
        title: req.body.title,
        genre: req.body.genre,
        author: req.body.author
        
    });

    genre.save()
        .then(data =>{
           res.json(data);
        })
        .catch(e=>{
            console.log(e.stack);
           
        })

        
});

router.delete('/:id',(req,res)=>{
    Genre.deleteOne({_id:req.params.id})
        .then(data => {
           return res.json(data);
        })
        .catch(e=>{
            res.json({message:e});
        })
});

router.patch('/:id',(req,res)=>{
    Genre.updateOne({_id:req.params.id},{
        $set:req.body
    })
    .then(data =>{
       res.json(data);
    })
    .catch(e =>{
        console.log(e.stack);
    })
});

module.exports=router;