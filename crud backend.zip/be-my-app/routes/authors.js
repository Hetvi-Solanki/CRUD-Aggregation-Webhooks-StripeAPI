const express = require('express');
const Author = require('../models/Author');
const router = express.Router();


router.get('/',(req,res)=>{

    
    Author.find()
        .then(data =>{
           res.json(data);
        })
        .catch(e=>{
            console.log(e.stack);
            
        })
        
        .catch(e=>{
            res.json({message:e})
        })

});

router.post('/',(req,res)=>{
    const author=new Author({
        auth_name: req.body.auth_name,
        no_of_books_written: req.body.no_of_books_written,
        book_type: req.body.book_type,
        no_of_copies_sold: req.body.no_of_copies_sold,
        age: req.body.age
        
    });

    author.save()
        .then(data =>{
           res.json(data);
        })
        .catch(e=>{
            console.log(e.stack);
           
        })

        
});

router.delete('/:id',(req,res)=>{
    Author.deleteOne({_id:req.params.id})
        .then(data => {
           return res.json(data);
        })
        .catch(e=>{
            res.json({message:e});
        })
});

router.patch('/:id',(req,res)=>{
    Author.updateOne({_id:req.params.id},{
        $set:req.body
    })
    .then(data =>{
       res.json(data);
    })
    .catch(e =>{
        console.log(e.stack);
    })
});

module.exports=router;