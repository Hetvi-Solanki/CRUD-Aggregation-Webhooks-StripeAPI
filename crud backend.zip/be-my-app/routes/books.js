const express = require('express');
const Book = require('../models/Book');
const router = express.Router();


router.get('/',(req,res)=>{

    
    Book.find()
        .then(data =>{
           res.json(data);
        })
        .catch(e=>{
            console.log(e.stack);
            
        })
        
        .catch(e=>{
            res.json({message:e})
        })

});

router.post('/',(req,res)=>{
    const book=new Book({
        title: req.body.title,
        description: req.body.description,
        author: req.body.author,
        price: req.body.price,
        stock: req.body.stock
    });

    book.save()
        .then(data =>{
           res.json(data);
        })
        .catch(e=>{
            console.log(e.stack);
           
        })

        
});

router.delete('/:id',(req,res)=>{
    Book.deleteOne({_id:req.params.id})
        .then(data => {
           return res.json(data);
        })
        .catch(e=>{
            res.json({message:e});
        })
});

router.patch('/:id',(req,res)=>{
    Book.updateOne({_id:req.params.id},{
        $set:req.body
    })
    .then(data =>{
       res.json(data);
    })
    .catch(e =>{
        console.log(e.stack);
    })
});

module.exports=router;
