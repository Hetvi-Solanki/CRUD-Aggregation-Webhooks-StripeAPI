const express = require('express');
const Customer = require('../models/Customer');
const router = express.Router();


router.get('/',(req,res)=>{

    
    Customer.find()
        .then(data =>{
           res.json(data);
        })
        .catch(e=>{
            console.log(e.stack);
            
        })
        
        .catch(e=>{
            res.json({message:e})
        })

});

router.post('/',(req,res)=>{
    const customer=new Customer({
        name: req.body.name,
        city: req.body.city,
        preferred_book_type: req.body.preferred_book_type,
        age: req.body.age
        
    });

    customer.save()
        .then(data =>{
           res.json(data);
        })
        .catch(e=>{
            console.log(e.stack);
           
        })

        
});

router.delete('/:id',(req,res)=>{
    Customer.deleteOne({_id:req.params.id})
        .then(data => {
           return res.json(data);
        })
        .catch(e=>{
            res.json({message:e});
        })
});

router.patch('/:id',(req,res)=>{
    Customer.updateOne({_id:req.params.id},{
        $set:req.body
    })
    .then(data =>{
       res.json(data);
    })
    .catch(e =>{
        console.log(e.stack);
    })
});

module.exports=router;