const mongoose=require('mongoose');

const AuthorSchema =new mongoose.Schema({
    auth_name:{
        type:String,
        required:true
    },
    no_of_books_written:{
        type:Number,
        required:true
    },
    book_type:{
        type:String,
        required:true
    },
    no_of_copies_sold:{
        type:Number,
        required:true
    },
    age:{
        type:Number,
        required:true
    }
});

var authors = mongoose.model('authors',AuthorSchema);
module.exports = authors;
