const mongoose=require('mongoose');

const GenreSchema =new mongoose.Schema({
    title:{
        type:String,
        required:true
    },
    genre:{
        type:String,
        required:true
    },
    author:{
        type:String,
        required:true
    }
});

var genres = mongoose.model('genres',GenreSchema);
module.exports = genres;
