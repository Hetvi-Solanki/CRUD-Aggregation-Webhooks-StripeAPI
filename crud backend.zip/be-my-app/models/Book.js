const mongoose=require('mongoose');

const BookSchema =new mongoose.Schema({
    title:{
        type:String,
        required:true
    },
    description:{
        type:String
    },
    author:{
        type:String,
        required:true
    },
    price:{
        type:Number,
        required:true
    },
    stock:{
        type:Number,
        required:true
    }
});

var books = mongoose.model('books',BookSchema);
module.exports = books;
