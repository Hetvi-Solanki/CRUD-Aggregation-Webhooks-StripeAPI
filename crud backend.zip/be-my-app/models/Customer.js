const mongoose=require('mongoose');

const CustomerSchema =new mongoose.Schema({
    name:{
        type:String,
        required:true
    },
    city:{
        type:String,
        required:true
    },
    preferred_book_type:[{
        type:String,
        required:true
    }],
    age:{
        type:Number,
        required:true
    }
});

var customers = mongoose.model('customers',CustomerSchema);
module.exports = customers;