const mongoose=require('mongoose');

const OrderSchema =new mongoose.Schema({
    book_name:{
        type:String,
        required:true
    },
    customer_name:{
        type:String,
        required:true
    },
    total_copies:{
        type:Number,
        required:true
    }
});

var orders = mongoose.model('orders',OrderSchema);
module.exports = orders;
